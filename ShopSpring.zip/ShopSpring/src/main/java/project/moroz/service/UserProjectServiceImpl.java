package project.moroz.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import project.moroz.model.Role;
import project.moroz.model.User;
import project.moroz.repository.DAO;
import project.moroz.repository.UserDAOImpl;


import java.util.List;

@Service
public class UserProjectServiceImpl implements UserProjectService<User> {
    private UserDAOImpl userDAO;

    @Autowired
    public void setUserDAO(@Qualifier("userDAOImpl") UserDAOImpl userDAO) {
        this.userDAO = userDAO;
    }

    @Override
    @Transactional
    public List<User> getList() {
        return userDAO.getList();
    }

    @Override
    @Transactional
    public void add(User user) {
        userDAO.add(user);
    }

    @Override
    @Transactional
    public void delete(User user) {
        userDAO.delete(user);
    }

    @Override
    @Transactional
    public void edit(User user) {
        userDAO.edit(user);
    }

    @Override
    @Transactional
    public User getById(int id) {
        return (User) userDAO.getById(id);
    }

    @Override
    public Role getRoleById(int id) {
        return null;
    }

//    @Override
//    public List<Role> getRoleList() {
//        return userDAO.getRoleList();
//    }
}
